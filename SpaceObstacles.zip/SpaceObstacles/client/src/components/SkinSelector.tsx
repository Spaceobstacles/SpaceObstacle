import { cn } from "@/lib/utils";
import { Check } from "lucide-react";

export interface Skin {
  id: string;
  name: string;
  src: string;
}

export const AVAILABLE_SKINS: Skin[] = [
  { id: "default", name: "MK-1 Standard", src: "/images/rocket-default.png" },
  { id: "classic", name: "Vostok Classic", src: "/images/rocket-classic.png" },
  { id: "modern", name: "X-Type Modern", src: "/images/rocket-modern.webp" },
  { id: "retro", name: "Retro Rocket", src: "/images/rocket-retro.png" },
  { id: "bnec", name: "BNEC ROCKET", src: "/images/rocket-bnec.png" },
];

interface SkinSelectorProps {
  selectedSkin: string;
  onSelect: (id: string) => void;
}

export function SkinSelector({ selectedSkin, onSelect }: SkinSelectorProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full">
      {AVAILABLE_SKINS.map((skin) => (
        <button
          key={skin.id}
          onClick={() => onSelect(skin.id)}
          className={cn(
            "group relative flex flex-col items-center gap-3 p-4 rounded-lg border transition-all duration-300",
            selectedSkin === skin.id
              ? "bg-white/10 border-white shadow-[0_0_15px_rgba(255,255,255,0.1)]"
              : "bg-black/40 border-white/10 hover:border-white/30 hover:bg-white/5"
          )}
        >
          <div className="relative w-16 h-16 md:w-20 md:h-20 flex items-center justify-center">
            {/* Fallback box if image fails to load during dev */}
            <div className="absolute inset-0 bg-white/5 rounded-full blur-md group-hover:bg-white/10 transition-colors" />
            <img 
              src={skin.src} 
              alt={skin.name}
              className="w-full h-full object-contain relative z-10 drop-shadow-[0_0_5px_rgba(255,255,255,0.5)]"
              onError={(e) => {
                // Fallback for when images aren't present yet
                e.currentTarget.style.display = 'none';
                e.currentTarget.parentElement!.innerHTML += '<div class="w-8 h-12 bg-gray-400 clip-path-polygon-[50%_0,100%_100%,0_100%]"></div>';
              }}
            />
          </div>
          
          <div className="text-center">
            <div className="font-mono text-xs text-white/60 uppercase tracking-widest mb-1">Class</div>
            <div className="font-display text-sm font-bold text-white group-hover:text-shadow-glow">{skin.name}</div>
          </div>

          {selectedSkin === skin.id && (
            <div className="absolute top-2 right-2 w-5 h-5 bg-white text-black rounded-full flex items-center justify-center shadow-lg">
              <Check className="w-3 h-3" strokeWidth={4} />
            </div>
          )}
        </button>
      ))}
    </div>
  );
}
