import { useEffect, useRef } from "react";

interface AudioEngineProps {
  isPlaying: boolean;
}

export function AudioEngine({ isPlaying }: AudioEngineProps) {
  const audioContext = useRef<AudioContext | null>(null);
  const gainNode = useRef<GainNode | null>(null);
  
  useEffect(() => {
    // Initialize AudioContext on first interaction or mount if possible
    // Note: Chrome requires user gesture before AudioContext can start
    const initAudio = () => {
      if (!audioContext.current) {
        audioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        
        // Create brown noise buffer
        const bufferSize = 4096;
        const brownNoise = (function() {
            var lastOut = 0;
            var node = audioContext.current!.createScriptProcessor(bufferSize, 1, 1);
            node.onaudioprocess = function(e) {
                var output = e.outputBuffer.getChannelData(0);
                for (var i = 0; i < bufferSize; i++) {
                    var white = Math.random() * 2 - 1;
                    output[i] = (lastOut + (0.02 * white)) / 1.02;
                    lastOut = output[i];
                    output[i] *= 3.5; // (roughly) compensate for gain
                }
            }
            return node;
        })();

        gainNode.current = audioContext.current.createGain();
        gainNode.current.gain.value = 0; // Start muted
        
        brownNoise.connect(gainNode.current);
        gainNode.current.connect(audioContext.current.destination);
      }
    };

    if (isPlaying) {
      initAudio();
      if (audioContext.current?.state === 'suspended') {
        audioContext.current.resume();
      }
      
      // Fade in
      if (gainNode.current) {
        gainNode.current.gain.setTargetAtTime(0.05, audioContext.current!.currentTime, 2);
      }
    } else {
      // Fade out
      if (gainNode.current && audioContext.current) {
        gainNode.current.gain.setTargetAtTime(0, audioContext.current.currentTime, 0.5);
      }
    }

    return () => {
      // Cleanup happens when component unmounts, but we keep context alive for re-renders usually
      // For this app, we can just mute it.
    };
  }, [isPlaying]);

  return null; // Headless component
}
