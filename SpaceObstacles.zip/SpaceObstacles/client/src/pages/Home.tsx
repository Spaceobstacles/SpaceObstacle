import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/Button";
import { SkinSelector } from "@/components/SkinSelector";
import { useScores } from "@/hooks/use-scores";
import { Loader2, Trophy, Rocket, ChevronRight, User, Lock, Map as MapIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export const MAPS = [
  { id: "space", name: "Deep Space", unlock: 0, description: "The classic void." },
  { id: "earth", name: "Earth Ascent", unlock: 5, description: "Pre-space sky climb." },
  { id: "void", name: "Void Ruins", unlock: 15, description: "Narrow paths through ruins." },
  { id: "alien", name: "Alien Invasion", unlock: 30, description: "The swarm is here." },
];

export default function Home() {
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState(localStorage.getItem("galaxy_username") || "");
  const [selectedSkin, setSelectedSkin] = useState(localStorage.getItem("galaxy_skin") || "default");
  const [selectedMap, setSelectedMap] = useState(localStorage.getItem("galaxy_map") || "space");
  
  const { data: scores, isLoading: isLoadingScores } = useScores();
  
  const maxDistanceKm = scores?.length ? Math.max(...scores.map(s => s.score / 100)) : 0;

  const handleStart = () => {
    if (!username.trim()) return;
    localStorage.setItem("galaxy_username", username);
    localStorage.setItem("galaxy_skin", selectedSkin);
    localStorage.setItem("galaxy_map", selectedMap);
    setLocation("/game");
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col relative overflow-hidden font-sans">
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-gray-800/20 via-black to-black pointer-events-none" />
      <div className="scanline" />

      {/* Main Content Area */}
      <div className="relative z-10 container mx-auto px-4 py-8 flex flex-col md:flex-row gap-12 flex-grow items-center justify-center h-full">
        
        {/* LEFT: Game Config */}
        <div className="w-full max-w-xl space-y-12 animate-in fade-in slide-in-from-left-8 duration-700">
          
          {/* Header */}
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 border border-white/20 rounded-full bg-white/5 text-xs uppercase tracking-widest text-gray-400">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              System Online
            </div>
            <h1 className="text-6xl md:text-8xl font-display font-black tracking-tight text-white leading-none text-shadow-glow">
              GALAXY<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-200 to-gray-600">OBSTACLES</span>
            </h1>
          </div>

          {/* Form */}
          <div className="space-y-8 bg-white/5 p-8 rounded-2xl border border-white/10 backdrop-blur-sm">
            
            {/* Name Input */}
            <div className="space-y-4">
              <label className="text-xs uppercase tracking-widest text-gray-500 font-bold flex items-center gap-2">
                <User className="w-4 h-4" /> Pilot Identity
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="ENTER CALLSIGN..."
                className="w-full bg-black/50 border-2 border-white/10 rounded-lg px-6 py-4 text-xl font-mono text-white placeholder:text-gray-700 focus:outline-none focus:border-white transition-all focus:shadow-[0_0_20px_rgba(255,255,255,0.1)]"
              />
            </div>

            {/* Map Selection */}
            <div className="space-y-4">
              <label className="text-xs uppercase tracking-widest text-gray-500 font-bold flex items-center gap-2">
                <MapIcon className="w-4 h-4" /> Sector Selection
              </label>
              <div className="grid grid-cols-2 gap-3">
                {MAPS.map((map) => {
                  const isLocked = maxDistanceKm < map.unlock;
                  return (
                    <button
                      key={map.id}
                      disabled={isLocked}
                      onClick={() => setSelectedMap(map.id)}
                      className={cn(
                        "relative flex flex-col items-start p-4 rounded-lg border transition-all text-left",
                        selectedMap === map.id
                          ? "bg-white text-black border-white shadow-[0_0_15px_rgba(255,255,255,0.3)]"
                          : isLocked
                          ? "bg-black/20 border-white/5 opacity-40 cursor-not-allowed"
                          : "bg-white/5 border-white/10 hover:border-white/30"
                      )}
                    >
                      <div className="font-bold uppercase tracking-tighter">{map.name}</div>
                      {isLocked ? (
                        <div className="text-[10px] flex items-center gap-1 mt-1 opacity-70">
                          <Lock className="w-2 h-2" /> Unlock at {map.unlock} KM
                        </div>
                      ) : (
                        <div className="text-[10px] mt-1 opacity-70 italic">{map.description}</div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Skin Selector */}
            <div className="space-y-4">
              <label className="text-xs uppercase tracking-widest text-gray-500 font-bold flex items-center gap-2">
                <Rocket className="w-4 h-4" /> Select Vessel
              </label>
              <SkinSelector selectedSkin={selectedSkin} onSelect={setSelectedSkin} />
            </div>

            {/* Start Button */}
            <Button 
              onClick={handleStart} 
              disabled={!username.trim()}
              className="w-full py-6 text-xl"
              size="lg"
            >
              INITIATE LAUNCH <ChevronRight className="ml-2 w-6 h-6" />
            </Button>
          </div>
        </div>

        {/* RIGHT: Leaderboard */}
        <div className="w-full max-w-md animate-in fade-in slide-in-from-right-8 duration-700 delay-150">
          <div className="bg-black/40 border border-white/10 rounded-xl overflow-hidden backdrop-blur-md">
            <div className="p-6 border-b border-white/10 bg-white/5 flex items-center justify-between">
              <h3 className="font-display font-bold text-xl flex items-center gap-2">
                <Trophy className="w-5 h-5 text-yellow-500" />
                ELITE PILOTS
              </h3>
              <div className="text-xs font-mono text-gray-500 uppercase">Best: {maxDistanceKm.toFixed(1)} KM</div>
            </div>
            
            <div className="divide-y divide-white/5 max-h-[400px] overflow-y-auto">
              {isLoadingScores ? (
                <div className="p-8 flex justify-center text-gray-500">
                  <Loader2 className="animate-spin w-8 h-8" />
                </div>
              ) : scores?.length === 0 ? (
                <div className="p-8 text-center text-gray-600 italic">No flight records found. Be the first.</div>
              ) : (
                scores?.map((score, idx) => (
                  <div key={score.id} className="p-4 flex items-center justify-between hover:bg-white/5 transition-colors group">
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        "w-8 h-8 flex items-center justify-center font-mono font-bold rounded-full text-xs",
                        idx === 0 ? "bg-white text-black" : 
                        idx === 1 ? "bg-gray-400 text-black" : 
                        idx === 2 ? "bg-gray-700 text-white" : "text-gray-600 bg-white/5"
                      )}>
                        {idx + 1}
                      </div>
                      <div className="flex flex-col">
                        <span className="font-bold text-white group-hover:text-shadow-glow transition-all">{score.username}</span>
                        <span className="text-[10px] text-gray-600 font-mono uppercase">{score.createdAt ? new Date(score.createdAt).toLocaleDateString() : 'N/A'}</span>
                      </div>
                    </div>
                    <div className="font-mono text-lg font-bold text-gray-300">
                      {(score.score / 100).toFixed(1)} <span className="text-xs text-gray-600">KM</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
