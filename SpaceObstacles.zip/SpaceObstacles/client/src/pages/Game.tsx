import { useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/Button";
import { AudioEngine } from "@/components/AudioEngine";
import { useCreateScore } from "@/hooks/use-scores";
import { AVAILABLE_SKINS } from "@/components/SkinSelector";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

interface GameState {
  isPlaying: boolean;
  isPaused: boolean;
  isGameOver: boolean;
  score: number; // Distance in meters (display as km)
  speed: number;
}

export default function Game() {
  const [location, setLocation] = useLocation();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>();
  const { toast } = useToast();
  
  // Game State
  const [gameState, setGameState] = useState<GameState>({
    isPlaying: true,
    isPaused: false,
    isGameOver: false,
    score: 0,
    speed: 3, // Slower start speed
  });

  // Load user prefs
  const username = localStorage.getItem("galaxy_username") || "Cadet";
  const skinId = localStorage.getItem("galaxy_skin") || "default";
  const mapId = localStorage.getItem("galaxy_map") || "space";
  const skinSrc = AVAILABLE_SKINS.find(s => s.id === skinId)?.src || AVAILABLE_SKINS[0].src;

  const { mutate: submitScore, isPending: isSubmitting } = useCreateScore();

  // Entities Ref (to avoid re-renders)
  const playerRef = useRef({ x: 0, y: 0, width: 80, height: 120, speed: 7, dx: 0 });
  const obstaclesRef = useRef<Array<{ x: number; y: number; width: number; height: number; type: string; pattern?: 'sine' | 'straight'; offset?: number }>>([]);
  const starsRef = useRef<Array<{ x: number; y: number; size: number; speed: number; opacity: number }>>([]);
  const backgroundRef = useRef<Array<{ x: number; y: number; size: number; speed: number; opacity: number; type: string }>>([]);
  const touchStartRef = useRef<{ x: number; y: number } | null>(null);
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const skinImgRef = useRef<HTMLImageElement>(new Image());

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Set initial size
    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      
      if (playerRef.current.x === 0) {
        playerRef.current.x = canvas.width / 2 - playerRef.current.width / 2;
        playerRef.current.y = canvas.height - 180;
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    skinImgRef.current.src = skinSrc;
    
    // Create background objects based on map
    const bgCount = mapId === 'earth' ? 10 : 5;
    for (let i = 0; i < bgCount; i++) {
      backgroundRef.current.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 100 + 50,
        speed: Math.random() * 0.2 + 0.05,
        opacity: Math.random() * 0.5 + 0.2,
        type: mapId === 'earth' ? 'cloud' : (Math.random() > 0.5 ? 'planet' : 'galaxy')
      });
    }

    // Stars only for space maps
    if (mapId !== 'earth') {
      for (let i = 0; i < 150; i++) {
        starsRef.current.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          size: Math.random() * 2 + 0.5,
          speed: Math.random() * 0.5 + 0.1,
          opacity: Math.random() * 0.8 + 0.2
        });
      }
    }

    // Touch handlers for mobile
    const handleTouchStart = (e: TouchEvent) => {
      e.preventDefault();
      touchStartRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    };

    const handleTouchMove = (e: TouchEvent) => {
      e.preventDefault();
      if (!touchStartRef.current) return;
      const dx = e.touches[0].clientX - touchStartRef.current.x;
      playerRef.current.x += dx; 
      touchStartRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    };

    const handleTouchEnd = () => {
      touchStartRef.current = null;
    };

    canvas.addEventListener('touchstart', handleTouchStart, { passive: false });
    canvas.addEventListener('touchmove', handleTouchMove, { passive: false });
    canvas.addEventListener('touchend', handleTouchEnd);

    // Input handlers
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.code] = true;
      if (e.code === 'Escape') {
        togglePause();
      }
    };
    
    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.code] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      canvas.removeEventListener('touchstart', handleTouchStart);
      canvas.removeEventListener('touchmove', handleTouchMove);
      canvas.removeEventListener('touchend', handleTouchEnd);
      cancelAnimationFrame(requestRef.current!);
    };
  }, [skinSrc, mapId]);

  const drawPlanet = (ctx: CanvasRenderingContext2D, x: number, y: number, size: number, opacity: number) => {
    ctx.save();
    ctx.font = `${size * 1.5}px serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.globalAlpha = opacity;
    ctx.fillText('🪐', x, y);
    ctx.restore();
  };

  const drawGalaxy = (ctx: CanvasRenderingContext2D, x: number, y: number, size: number, opacity: number) => {
    ctx.save();
    ctx.font = `${size * 1.5}px serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.globalAlpha = opacity;
    ctx.fillText('🌌', x, y);
    ctx.restore();
  };

  const drawCloud = (ctx: CanvasRenderingContext2D, x: number, y: number, size: number, opacity: number) => {
    ctx.save();
    ctx.font = `${size * 1.5}px serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.globalAlpha = opacity;
    ctx.fillText('☁️', x, y);
    ctx.restore();
  };

  // Game Loop
  const gameLoop = () => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (gameState.isPaused || gameState.isGameOver) {
      if (gameState.isPaused) return;
    }

    // 1. Move Player
    if (keysRef.current['KeyA'] || keysRef.current['ArrowLeft']) {
      playerRef.current.x -= playerRef.current.speed;
    }
    if (keysRef.current['KeyD'] || keysRef.current['ArrowRight']) {
      playerRef.current.x += playerRef.current.speed;
    }

    if (playerRef.current.x < 0) playerRef.current.x = 0;
    if (playerRef.current.x > canvas.width - playerRef.current.width) playerRef.current.x = canvas.width - playerRef.current.width;

    // 2. Move & Spawn Obstacles
    if (Math.random() < 0.02 + (gameState.speed * 0.001)) {
      const size = Math.random() * 40 + 40;
      let type = 'asteroid';
      let pattern: 'sine' | 'straight' = 'straight';
      
      if (mapId === 'earth') {
        type = Math.random() > 0.5 ? 'cloud' : 'bird';
      } else if (mapId === 'void') {
        type = 'ruin';
      } else if (mapId === 'alien') {
        type = 'alien';
        pattern = Math.random() > 0.5 ? 'sine' : 'straight';
      } else {
        type = Math.random() > 0.8 ? 'debris' : 'asteroid';
      }

      obstaclesRef.current.push({
        x: Math.random() * (canvas.width - size),
        y: -100,
        width: size,
        height: size,
        type,
        pattern,
        offset: Math.random() * Math.PI * 2
      });
    }

    for (let i = obstaclesRef.current.length - 1; i >= 0; i--) {
      const obs = obstaclesRef.current[i];
      obs.y += gameState.speed;
      
      if (obs.pattern === 'sine') {
        obs.x += Math.sin(Date.now() * 0.005 + (obs.offset || 0)) * 3;
      }

      if (
        playerRef.current.x < obs.x + obs.width * 0.7 &&
        playerRef.current.x + playerRef.current.width * 0.7 > obs.x &&
        playerRef.current.y < obs.y + obs.height * 0.7 &&
        playerRef.current.y + playerRef.current.height * 0.7 > obs.y
      ) {
        handleGameOver();
        return;
      }

      if (obs.y > canvas.height + 100) {
        obstaclesRef.current.splice(i, 1);
      }
    }

    // 3. Move Parallax
    backgroundRef.current.forEach(bg => {
      bg.y += bg.speed + (gameState.speed * 0.05);
      if (bg.y > canvas.height + bg.size) {
        bg.y = -bg.size;
        bg.x = Math.random() * canvas.width;
      }
    });

    starsRef.current.forEach(star => {
      star.y += star.speed + (gameState.speed * 0.1);
      if (star.y > canvas.height) {
        star.y = 0;
        star.x = Math.random() * canvas.width;
      }
    });

    // 4. Update Score & Speed
    setGameState(prev => {
      const newScore = prev.score + (prev.speed * 0.05);
      const newSpeed = Math.min(prev.speed + 0.0005, 15);
      return { ...prev, score: newScore, speed: newSpeed };
    });

    // RENDER
    ctx.fillStyle = mapId === 'earth' ? '#87CEEB' : '#000000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    backgroundRef.current.forEach(bg => {
      if (bg.type === 'planet') drawPlanet(ctx, bg.x, bg.y, bg.size, bg.opacity);
      else if (bg.type === 'galaxy') drawGalaxy(ctx, bg.x, bg.y, bg.size, bg.opacity);
      else if (bg.type === 'cloud') drawCloud(ctx, bg.x, bg.y, bg.size, bg.opacity);
    });

    starsRef.current.forEach(star => {
      ctx.fillStyle = `rgba(255, 255, 255, ${star.opacity})`;
      ctx.beginPath();
      ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
      ctx.fill();
    });

    // Draw Player
    ctx.save();
    ctx.shadowBlur = 20;
    ctx.shadowColor = mapId === 'earth' ? "rgba(0, 0, 0, 0.2)" : "rgba(255, 255, 255, 0.5)";
    
    if (skinImgRef.current.complete && skinImgRef.current.naturalWidth > 0) {
      ctx.drawImage(skinImgRef.current, playerRef.current.x, playerRef.current.y, playerRef.current.width, playerRef.current.height);
    } else {
      ctx.fillStyle = mapId === 'earth' ? '#333' : '#fff';
      ctx.fillRect(playerRef.current.x, playerRef.current.y, playerRef.current.width, playerRef.current.height);
    }
    ctx.restore();

    // Draw Obstacles
    obstaclesRef.current.forEach(obs => {
      ctx.save();
      ctx.font = `${obs.width}px serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      let emoji = '☄️';
      if (obs.type === 'debris') emoji = '🛰️';
      if (obs.type === 'cloud') emoji = '☁️';
      if (obs.type === 'bird') emoji = '🦅';
      if (obs.type === 'ruin') emoji = '🏛️';
      if (obs.type === 'alien') emoji = '🛸';
      ctx.fillText(emoji, obs.x + obs.width / 2, obs.y + obs.height / 2);
      ctx.restore();
    });

    requestRef.current = requestAnimationFrame(gameLoop);
  };

  // Start/Resume loop when playing state changes
  useEffect(() => {
    if (gameState.isPlaying && !gameState.isPaused && !gameState.isGameOver) {
      requestRef.current = requestAnimationFrame(gameLoop);
    }
    return () => cancelAnimationFrame(requestRef.current!);
  }, [gameState.isPlaying, gameState.isPaused, gameState.isGameOver]);

  // Helpers
  const togglePause = () => {
    if (gameState.isGameOver) return;
    setGameState(prev => ({ ...prev, isPaused: !prev.isPaused }));
  };

  const handleGameOver = () => {
    setGameState(prev => ({ ...prev, isGameOver: true, isPlaying: false }));
  };

  const handleSaveScore = async () => {
    try {
      await submitScore({
        username,
        score: Math.floor(gameState.score),
        skin: skinId,
      });
      toast({ title: "Score Saved!", description: "Your legacy is recorded in the stars." });
      
      // Clear game-specific selection after run
      // localStorage.removeItem("galaxy_map"); 
      
      setLocation("/");
    } catch (e) {
      toast({ title: "Error", description: "Could not save score.", variant: "destructive" });
    }
  };

  // Display value
  const distanceKm = (gameState.score / 100).toFixed(1);

  return (
    <div className="relative w-full h-screen overflow-hidden bg-black text-white font-mono">
      {/* Game Canvas */}
      <canvas ref={canvasRef} className="block" />
      
      {/* Audio Engine */}
      <AudioEngine isPlaying={gameState.isPlaying && !gameState.isPaused && !gameState.isGameOver} />

      {/* HUD */}
      <div className="absolute top-6 left-6 z-10 flex flex-col gap-2 pointer-events-none">
        <h2 className="text-4xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-500">
          {distanceKm} <span className="text-lg text-gray-400">KM</span>
        </h2>
        <div className="text-xs text-gray-500">SPEED: {gameState.speed.toFixed(1)} MACH</div>
      </div>

      {/* Pause Menu Overlay */}
      {gameState.isPaused && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="flex flex-col gap-6 text-center border border-white/20 p-12 bg-black/90 shadow-2xl rounded-lg max-w-md w-full">
            <h2 className="text-3xl font-display tracking-widest text-white mb-4">SYSTEM PAUSED</h2>
            <Button onClick={togglePause} variant="primary" size="lg">RESUME MISSION</Button>
            <Button onClick={() => setLocation("/")} variant="outline">ABORT TO MENU</Button>
          </div>
        </div>
      )}

      {/* Game Over Overlay */}
      {gameState.isGameOver && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/90 animate-in zoom-in-95 duration-300">
          <div className="flex flex-col items-center gap-6 text-center max-w-lg w-full p-8 border-y-2 border-white/20 bg-gradient-to-b from-transparent via-white/5 to-transparent">
            <div className="space-y-2">
              <h2 className="text-5xl font-display font-black text-white tracking-wider text-shadow-glow">
                MISSION FAILED
              </h2>
              <p className="text-gray-400 font-mono text-sm uppercase tracking-widest">Collision Detected</p>
            </div>

            <div className="py-8 space-y-2">
              <div className="text-xs text-gray-500 uppercase tracking-widest">Final Distance</div>
              <div className="text-6xl font-mono font-bold text-white">{distanceKm} <span className="text-2xl">KM</span></div>
            </div>

            <div className="flex flex-col gap-3 w-full max-w-xs">
              <Button 
                onClick={handleSaveScore} 
                variant="primary" 
                size="lg"
                disabled={isSubmitting}
              >
                {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                {isSubmitting ? "TRANSMITTING..." : "SAVE & EXIT"}
              </Button>
              <Button onClick={() => window.location.reload()} variant="outline">RETRY IMMEDIATELY</Button>
            </div>
          </div>
        </div>
      )}

      {/* Vignette & Scanlines */}
      <div className="vignette" />
      <div className="scanline" />
    </div>
  );
}
