import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/Button";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-black text-white p-4">
      <Card className="w-full max-w-md bg-white/5 border-white/10 backdrop-blur">
        <CardContent className="pt-6">
          <div className="flex mb-4 gap-2 text-destructive font-display uppercase tracking-widest items-center">
            <AlertCircle className="h-8 w-8" />
            <h1 className="text-2xl font-bold">404 Lost in Space</h1>
          </div>

          <p className="mt-4 text-sm text-gray-400 font-mono">
            The coordinates you are attempting to reach do not exist in this sector.
          </p>
          
          <div className="mt-8">
            <Link href="/" className="w-full">
               <Button className="w-full">Return to Base</Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
