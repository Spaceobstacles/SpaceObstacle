## Packages
framer-motion | Essential for smooth UI transitions and menu animations
lucide-react | Icons for the UI (already in base but ensuring availability)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Orbitron'", "sans-serif"],
  mono: ["'Space Mono'", "monospace"],
  sans: ["'Inter'", "sans-serif"],
}
Game uses HTML5 Canvas for performance.
Rocket skins are located at:
- /images/rocket-default.png (Default)
- /images/rocket-classic.png
- /images/rocket-modern.webp
- /images/rocket-retro.png
Audio is generated via Web Audio API (no external assets needed).
