# Galaxy Obstacles

## Overview

Galaxy Obstacles is a browser-based arcade game where players pilot a rocket through space, dodging asteroids and debris to achieve the highest distance. The application features a React frontend with an HTML5 Canvas game engine, an Express backend API, and PostgreSQL for persistent leaderboard storage. Players can customize their rocket with different skins and compete for top scores on a global leaderboard.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript, using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing (Home and Game pages)
- **State Management**: TanStack React Query for server state, local React state for UI
- **Styling**: Tailwind CSS with shadcn/ui component library (New York style)
- **Game Engine**: HTML5 Canvas for rendering, Web Audio API for sound effects
- **Path Aliases**: `@/` maps to `client/src/`, `@shared/` maps to `shared/`

### Backend Architecture
- **Framework**: Express 5 on Node.js with TypeScript
- **API Design**: RESTful endpoints defined in `shared/routes.ts` with Zod validation
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Build Process**: esbuild bundles server code, Vite handles client builds

### Data Layer
- **Database**: PostgreSQL (requires `DATABASE_URL` environment variable)
- **Schema Location**: `shared/schema.ts` using Drizzle's pgTable definitions
- **Migrations**: Drizzle Kit with output to `./migrations` directory
- **Current Tables**: `scores` table storing username, score (distance in KM), skin ID, and timestamp

### Code Organization
```
client/           # React frontend
  src/
    components/   # Reusable UI components
    pages/        # Route pages (Home, Game)
    hooks/        # Custom React hooks
    lib/          # Utilities and query client
server/           # Express backend
  index.ts        # Server entry point
  routes.ts       # API route handlers
  storage.ts      # Database access layer
  db.ts           # Database connection
shared/           # Shared code between client/server
  schema.ts       # Drizzle database schema
  routes.ts       # API route definitions with types
```

### Development vs Production
- Development: Vite dev server with HMR, tsx for running TypeScript
- Production: Built to `dist/` directory, static files served from `dist/public`

## External Dependencies

### Database
- **PostgreSQL**: Primary data store, connected via `pg` pool
- **Connection**: Requires `DATABASE_URL` environment variable
- **Session Store**: `connect-pg-simple` available for session persistence

### UI Component Libraries
- **shadcn/ui**: Full component library with Radix UI primitives
- **Radix UI**: Accessible component primitives (dialog, dropdown, tooltip, etc.)
- **Lucide React**: Icon library

### Key Runtime Dependencies
- **drizzle-orm**: Type-safe ORM for PostgreSQL
- **drizzle-zod**: Schema validation integration
- **@tanstack/react-query**: Server state management
- **zod**: Runtime type validation for API inputs/outputs
- **wouter**: Client-side routing

### Build Tools
- **Vite**: Frontend bundler with React plugin
- **esbuild**: Server-side bundling for production
- **tsx**: TypeScript execution for development
- **Tailwind CSS**: Utility-first CSS framework